package com.anexai.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.anexai.app.audio.AmbientMusicManager
import com.anexai.app.audio.VoiceAssistantManager
import com.anexai.app.data.PreferencesManager
import com.anexai.app.ui.AnexOrbCanvas
import com.anexai.app.ui.SettingsBottomSheet

enum class AssistantState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    ERROR
}

class MainActivity : ComponentActivity() {

    private lateinit var prefsManager: PreferencesManager
    private lateinit var voiceAssistant: VoiceAssistantManager
    private lateinit var ambientMusic: AmbientMusicManager

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            voiceAssistant.startListening()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge immersive full screen
        WindowCompat.setDecorFitsSystemWindows(window, false)

        prefsManager = PreferencesManager(this)
        ambientMusic = AmbientMusicManager(this)
        voiceAssistant = VoiceAssistantManager(
            context = this,
            prefs = prefsManager,
            onStateChanged = { /* state handled in Compose via state flow */ },
            onDuckMusic = { duck -> ambientMusic.duck(duck) }
        )

        setContent {
            val assistantState by voiceAssistant.state.collectAsState()
            var showSettings by remember { mutableStateOf(false) }

            // Full-screen immersive layout with ZERO visible text on the home screen
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF030712)) // Deep obsidian background
                    .systemBarsPadding()
            ) {
                // Central 3D fluid animated AI Orb - Tappable to toggle voice
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AnexOrbCanvas(
                        state = assistantState,
                        reducedMotion = prefsManager.isReducedMotion,
                        animationQuality = prefsManager.animationQuality,
                        modifier = Modifier
                            .size(320.dp)
                            .clickable(
                                indication = null,
                                interactionSource = remember { MutableInteractionSource() }
                            ) {
                                handleOrbTap()
                            }
                    )
                }

                // Sole control on screen: Small subtle settings gear icon on side
                IconButton(
                    onClick = { showSettings = true },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 16.dp, end = 20.dp)
                        .size(44.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Settings,
                        contentDescription = "Settings",
                        tint = Color(0x66FFFFFF) // Subtle low-contrast gear icon
                    )
                }

                // Hidden Settings Modal / BottomSheet
                if (showSettings) {
                    SettingsBottomSheet(
                        prefs = prefsManager,
                        voiceAssistant = voiceAssistant,
                        ambientMusic = ambientMusic,
                        onDismiss = { showSettings = false }
                    )
                }
            }
        }
    }

    private fun handleOrbTap() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        } else {
            voiceAssistant.toggleVoice()
        }
    }

    override fun onPause() {
        super.onPause()
        voiceAssistant.stopListening()
        voiceAssistant.stopSpeaking()
        ambientMusic.duck(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceAssistant.release()
        ambientMusic.release()
    }
}
