package com.anexai.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.util.Log

class AmbientMusicManager(private val context: Context) {
    private var mediaPlayer: MediaPlayer? = null
    private var isPlaying = false

    fun play() {
        try {
            isPlaying = true
        } catch (e: Exception) {
            Log.e("AnexAI", "Music playback exception", e)
        }
    }

    fun stop() {
        mediaPlayer?.pause()
        isPlaying = false
    }

    fun duck(duck: Boolean) {
        val volume = if (duck) 0.15f else 0.8f
        mediaPlayer?.setVolume(volume, volume)
    }

    fun release() {
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
