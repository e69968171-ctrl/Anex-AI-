package com.anexai.app.audio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import com.anexai.app.AssistantState
import com.anexai.app.data.PreferencesManager
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class VoiceAssistantManager(
    private val context: Context,
    private val prefs: PreferencesManager,
    private val onStateChanged: (AssistantState) -> Unit,
    private val onDuckMusic: (Boolean) -> Unit
) : RecognitionListener {

    private val _state = MutableStateFlow(AssistantState.IDLE)
    val state: StateFlow<AssistantState> = _state

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // Gemini Model instance configured with Anas Memon creator identity
    private val generativeModel = GenerativeModel(
        modelName = "gemini-1.5-flash",
        apiKey = prefs.geminiApiKey
    )

    init {
        initSpeechRecognizer()
        initTextToSpeech()
    }

    private fun setState(newState: AssistantState) {
        _state.value = newState
        onStateChanged(newState)
        onDuckMusic(newState == AssistantState.SPEAKING)
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@VoiceAssistantManager)
            }
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale("hi", "IN")
            }
        }
    }

    fun toggleVoice() {
        when (_state.value) {
            AssistantState.LISTENING -> stopListening()
            AssistantState.SPEAKING -> stopSpeaking()
            AssistantState.THINKING -> setState(AssistantState.IDLE)
            AssistantState.IDLE, AssistantState.ERROR -> startListening()
        }
    }

    fun startListening() {
        stopSpeaking()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
        setState(AssistantState.LISTENING)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        if (_state.value == AssistantState.LISTENING) {
            setState(AssistantState.IDLE)
        }
    }

    fun stopSpeaking() {
        textToSpeech?.stop()
        if (_state.value == AssistantState.SPEAKING) {
            setState(AssistantState.IDLE)
        }
    }

    override fun onResults(results: Bundle?) {
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val spokenText = matches?.firstOrNull()?.trim()

        if (!spokenText.isNullOrEmpty()) {
            handleSpokenText(spokenText)
        } else {
            setState(AssistantState.IDLE)
        }
    }

    fun handleSpokenText(userQuery: String) {
        setState(AssistantState.THINKING)

        val lower = userQuery.lowercase()
        // Fast local answer for creator identity
        if (lower.contains("who made you") || lower.contains("who created you") || lower.contains("who is your creator") || lower.contains("kisne banaya") || lower.contains("aapko kisne banaya")) {
            val reply = if (prefs.selectedLanguage.contains("English")) {
                "Anas Memon created Anex AI."
            } else if (prefs.selectedLanguage.contains("Urdu")) {
                "Anex AI کو انس میمن نے بنایا ہے۔"
            } else if (prefs.selectedLanguage.contains("Sindhi")) {
                "Anex AI کي انس ميمڻ ٺاهيو آهي."
            } else {
                "Anex AI ko Anas Memon ne banaya hai."
            }
            speakResponse(reply)
            return
        }

        // Fast local answer for user name
        if (lower.contains("mera naam kya hai") || lower.contains("what is my name")) {
            if (prefs.userName.isNotBlank()) {
                val reply = "Aapka naam ${prefs.userName} hai."
                speakResponse(reply)
                return
            }
        }

        coroutineScope.launch {
            try {
                val currentDateStr = java.text.SimpleDateFormat("EEEE, dd MMMM yyyy", java.util.Locale.getDefault()).format(java.util.Date())
                val userGreeting = if (prefs.userName.isNotBlank()) "User name is ${prefs.userName}." else ""
                val prompt = "Today is $currentDateStr. User speaks: \"$userQuery\". You are Anex AI, an intelligent personal voice assistant created by Anas Memon. $userGreeting Answer the question accurately, conversationally, and concisely for voice conversation in natural Hindi by default or the user's spoken language. Step-by-step for maths/calculations. No markdown asterisks."
                val response = withContext(Dispatchers.IO) {
                    generativeModel.generateContent(prompt)
                }

                val replyText = response.text?.trim() ?: "Main sun raha hoon, kahiye."
                speakResponse(replyText)
            } catch (e: Exception) {
                Log.e("AnexAI", "Gemini response error", e)
                setState(AssistantState.ERROR)
                delay(1500)
                setState(AssistantState.IDLE)
            }
        }
    }

    private fun speakResponse(text: String) {
        setState(AssistantState.SPEAKING)
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "anex_reply")

        coroutineScope.launch {
            val estimatedDurationMs = (text.length * 75L).coerceAtLeast(1800L)
            delay(estimatedDurationMs)
            if (_state.value == AssistantState.SPEAKING) {
                setState(AssistantState.IDLE)
            }
        }
    }

    override fun onError(error: Int) {
        Log.w("AnexAI", "Recognition error code: $error")
        setState(AssistantState.IDLE)
    }

    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(partialResults: Bundle?) {}
    override fun onEvent(eventType: Int, params: Bundle?) {}

    fun release() {
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        coroutineScope.cancel()
    }
}
