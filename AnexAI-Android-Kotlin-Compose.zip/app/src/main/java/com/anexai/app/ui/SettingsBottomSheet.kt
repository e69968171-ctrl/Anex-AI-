package com.anexai.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.anexai.app.audio.AmbientMusicManager
import com.anexai.app.audio.VoiceAssistantManager
import com.anexai.app.data.PreferencesManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(
    prefs: PreferencesManager,
    voiceAssistant: VoiceAssistantManager,
    ambientMusic: AmbientMusicManager,
    onDismiss: () -> Unit
) {
    var userNameInput by remember { mutableStateOf(prefs.userName) }
    var fallbackTextInput by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F172A),
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = "Anex AI Settings",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White
            )
            Text(
                text = "Created by Anas Memon",
                style = MaterialTheme.typography.labelMedium,
                color = Color(0xFF38BDF8)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // User Name Section
            Text(
                text = "What should I call you?",
                style = MaterialTheme.typography.titleSmall,
                color = Color(0xFF94A3B8)
            )
            OutlinedTextField(
                value = userNameInput,
                onValueChange = {
                    userNameInput = it
                    prefs.userName = it
                },
                placeholder = { Text("Enter your name (e.g. Rahul, Ali)...") },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Direct Text Query Fallback
            Text(
                text = "Text Message Fallback",
                style = MaterialTheme.typography.titleSmall,
                color = Color(0xFF94A3B8)
            )
            Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                OutlinedTextField(
                    value = fallbackTextInput,
                    onValueChange = { fallbackTextInput = it },
                    placeholder = { Text("Ask who made you or anything...") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (fallbackTextInput.isNotBlank()) {
                            val text = fallbackTextInput
                            fallbackTextInput = ""
                            onDismiss()
                            voiceAssistant.handleSpokenText(text)
                        }
                    }
                ) {
                    Text("Send")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color(0x33FFFFFF))
            Spacer(modifier = Modifier.height(16.dp))

            // Primary Language Selection (Default Hindi)
            Text(
                text = "Primary Language (Default: Hindi)",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFF94A3B8)
            )
            val languages = listOf("Hindi (हिन्दी)", "Urdu (اردو)", "Roman Urdu", "Sindhi (سنڌي)", "English", "Arabic (العربية)")
            var selectedLang by remember { mutableStateOf(prefs.selectedLanguage) }

            languages.forEach { lang ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = lang, color = Color.White)
                    RadioButton(
                        selected = selectedLang == lang,
                        onClick = {
                            selectedLang = lang
                            prefs.selectedLanguage = lang
                        }
                    )
                }
            }

            HorizontalDivider(color = Color(0x33FFFFFF), modifier = Modifier.padding(vertical = 16.dp))

            // Background Instrumental Music
            var musicEnabled by remember { mutableStateOf(prefs.isMusicEnabled) }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Background Ambient Music", color = Color.White)
                    Text("Auto-ducks during speech", color = Color(0xFF64748B), style = MaterialTheme.typography.bodySmall)
                }
                Switch(
                    checked = musicEnabled,
                    onCheckedChange = {
                        musicEnabled = it
                        prefs.isMusicEnabled = it
                        if (it) ambientMusic.play() else ambientMusic.stop()
                    }
                )
            }

            HorizontalDivider(color = Color(0x33FFFFFF), modifier = Modifier.padding(vertical = 16.dp))

            // Creator Identity & Diagnostics
            Text("App Identity & Diagnostics", style = MaterialTheme.typography.titleMedium, color = Color(0xFF94A3B8))
            Text("Creator: Anas Memon", color = Color(0xFF38BDF8), style = MaterialTheme.typography.bodySmall)
            Text("Intelligence Engine: Google Gemini 3.8 Flash (Free Tier)", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.bodySmall)
            Text("Speech Engine: Android Native SpeechRecognizer + TextToSpeech", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.bodySmall)

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
