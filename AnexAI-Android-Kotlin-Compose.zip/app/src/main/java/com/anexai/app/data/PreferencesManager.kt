package com.anexai.app.data

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("anex_prefs", Context.MODE_PRIVATE)

    var userName: String
        get() = prefs.getString("user_name", "") ?: ""
        set(value) = prefs.edit().putString("user_name", value).apply()

    var selectedLanguage: String
        get() = prefs.getString("selected_language", "Hindi (हिन्दी)") ?: "Hindi (हिन्दी)"
        set(value) = prefs.edit().putString("selected_language", value).apply()

    var isMusicEnabled: Boolean
        get() = prefs.getBoolean("music_enabled", false)
        set(value) = prefs.edit().putBoolean("music_enabled", value).apply()

    var isReducedMotion: Boolean
        get() = prefs.getBoolean("reduced_motion", false)
        set(value) = prefs.edit().putBoolean("reduced_motion", value).apply()

    var animationQuality: String
        get() = prefs.getString("anim_quality", "high") ?: "high"
        set(value) = prefs.edit().putString("anim_quality", value).apply()

    var geminiApiKey: String
        get() = prefs.getString("gemini_key", "") ?: ""
        set(value) = prefs.edit().putString("gemini_key", value).apply()
}
