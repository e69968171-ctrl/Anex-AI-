package com.anexai.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.anexai.app.AssistantState
import kotlin.math.*

@Composable
fun AnexOrbCanvas(
    state: AssistantState,
    reducedMotion: Boolean,
    animationQuality: String,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "AnexOrbLoop")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (reducedMotion) 8000 else 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "time"
    )

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseRadius = min(size.width, size.height) * 0.28f

        // State-reactive radius and color shifts
        val radiusMultiplier = when (state) {
            AssistantState.LISTENING -> 1.15f + sin(time * 3f) * 0.04f
            AssistantState.THINKING -> 0.95f + sin(time * 5f) * 0.02f
            AssistantState.SPEAKING -> 1.10f + sin(time * 4f) * 0.06f
            AssistantState.ERROR -> 0.98f
            AssistantState.IDLE -> 1.0f + sin(time * 1.5f) * 0.035f // Gentle breathing
        }

        val r = baseRadius * radiusMultiplier
        val floatY = if (reducedMotion) 0f else sin(time) * 10f
        val center = Offset(cx, cy + floatY)

        // 1. Deep Shadow Beneath Orb
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x77000000), Color.Transparent),
                center = Offset(cx, cy + baseRadius * 1.3f),
                radius = baseRadius * 0.9f
            ),
            topLeft = Offset(cx - baseRadius * 0.9f, cy + baseRadius * 1.1f),
            size = androidx.compose.ui.geometry.Size(baseRadius * 1.8f, baseRadius * 0.45f)
        )

        // 2. Reactive Soundwaves (Listening / Speaking)
        if (state == AssistantState.LISTENING || state == AssistantState.SPEAKING) {
            val ringColor = if (state == AssistantState.LISTENING) Color(0x6638BDF8) else Color(0x66A855F7)
            drawCircle(
                color = ringColor,
                radius = r * (1.25f + sin(time * 2f) * 0.1f),
                center = center,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )
        }

        // 3. Volumetric 3D Spherical Shader Brush
        val primaryGlow = when (state) {
            AssistantState.LISTENING -> Color(0xFF38BDF8)
            AssistantState.THINKING -> Color(0xFFA855F7)
            AssistantState.SPEAKING -> Color(0xFFEC4899)
            AssistantState.ERROR -> Color(0xFFF97316)
            AssistantState.IDLE -> Color(0xFF6366F1)
        }

        val sphereBrush = Brush.radialGradient(
            colors = listOf(
                Color.White,
                primaryGlow,
                Color(0xFF0F172A),
                Color(0xFF020617)
            ),
            center = Offset(center.x - r * 0.35f, center.y - r * 0.35f),
            radius = r * 1.25f
        )

        // 4. Draw Core 3D Fluid Sphere
        drawCircle(
            brush = sphereBrush,
            radius = r,
            center = center
        )

        // 5. Specular Highlight
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xE6FFFFFF), Color.Transparent),
                center = Offset(center.x - r * 0.35f, center.y - r * 0.38f),
                radius = r * 0.35f
            ),
            radius = r * 0.35f,
            center = Offset(center.x - r * 0.35f, center.y - r * 0.38f)
        )
    }
}
