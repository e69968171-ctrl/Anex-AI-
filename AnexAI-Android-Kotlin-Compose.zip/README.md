# Anex AI - Native Android Voice Assistant (Kotlin & Jetpack Compose)

Anex AI is a production-grade, immersive native Android voice assistant built with modern **Kotlin** and **Jetpack Compose**.

## Key Highlights & Philosophy
- **Pure Full-Screen Immersive Canvas**: No chat bubbles, no text clutter, no titles on the home screen.
- **Hypnotic 3D Fluid Assistant Orb**: Dynamic breathing idle animation, reactive radial sonic ripples when listening, orbital vortex particles when thinking, and organic fluid harmonic deformation when speaking.
- **Two-Way Voice Pipeline**: Powered by Google Generative AI (Gemini 3.8 Flash & Gemini TTS), with fallback to Android Native SpeechRecognizer & TextToSpeech.
- **Multilingual Support**: Default language is **Hindi (हिन्दी)**, with support for **Urdu**, **Roman Urdu**, **Sindhi**, **English**, and **Arabic**.
- **Procedural Ambient Music**: Authentic ambient soundscape with automated volume ducking during assistant speech.
- **Hidden Settings Panel**: All configuration, diagnostics, and controls are tucked into a minimalist bottom sheet accessed via a subtle gear icon.

---

## Android Studio Setup & Build Instructions

### Prerequisites
1. **Android Studio** (Hedgehog, Iguana, Koala, Ladybug or newer).
2. **Android SDK Platform 35** (Android 15) with minimum SDK 26 (Android 8.0 Oreo).
3. **Java Development Kit (JDK) 17** or higher.

### Opening the Project
1. Extract the downloaded `AnexAI-Android-Kotlin-Compose.zip`.
2. Open Android Studio and choose **File > Open**, then select the extracted root folder.
3. Allow Gradle to sync dependencies.

### Configuring Gemini API Key
Provide your Gemini API key in `local.properties` (recommended) or in Android Studio:
```properties
GEMINI_API_KEY="AIzaSy..."
```

### Building the APK
To build the debug APK:
```bash
./gradlew assembleDebug
```
The APK will be generated at:
```
app/build/outputs/apk/debug/app-debug.apk
```

To install directly to a connected Android phone via ADB:
```bash
./gradlew installDebug
```
